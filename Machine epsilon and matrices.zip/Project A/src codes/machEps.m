function machEps()
x = 1;

while 1 + x/2 ~= 1
    x = x/2;
end
disp(x);
end